### Hexlet tests and linter status:
[![Actions Status](https://github.com/remortalite/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/remortalite/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3dd1c4f30ced308b9329/maintainability)](https://codeclimate.com/github/remortalite/python-project-49/maintainability)

Example:

# Game `brain-even`

[![asciicast](https://asciinema.org/a/GEFf0CCSj8sMISAXFZ7PnYYjW.svg)](https://asciinema.org/a/GEFf0CCSj8sMISAXFZ7PnYYjW)

# Game `brain-calc`

[![asciicast](https://asciinema.org/a/YIy5voxvo3B9r8fYt98y2n4Te.svg)](https://asciinema.org/a/YIy5voxvo3B9r8fYt98y2n4Te)

# Game `brain-gcd`

[![asciicast](https://asciinema.org/a/bPvvct1coQ0sIvVThRrlBVBPh.svg)](https://asciinema.org/a/bPvvct1coQ0sIvVThRrlBVBPh)
